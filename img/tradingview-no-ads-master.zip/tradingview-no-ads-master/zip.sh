#!/bin/bash

zip -r extension.zip . -x '*.git*' -x '*zip*'

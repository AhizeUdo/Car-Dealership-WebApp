## TradingView NoAds

A simple extension based on [this script](https://greasyfork.org/en/scripts/371211-tradingview-remove-ads/code) that removes the ads from the free plan of TradingView. It also prevents the "Upgrade to pro" modal from poping up when you close the ad, which is annoying too.
